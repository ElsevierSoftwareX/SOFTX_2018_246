function result = mnthetac( u, m)
%MNTHC Neville theta function C

result = nthetac( u, melnome(m));

end