function result = jtheta3( x, q)
%JTHETA1 Calculate Jacobi theta3(x,q)

    result = jtheta0( 3, x, q);
    
end

