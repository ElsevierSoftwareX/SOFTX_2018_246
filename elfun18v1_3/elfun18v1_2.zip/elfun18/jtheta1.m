function result = jtheta1( x, q)
%JTHETA1 Calculate Jacobi theta1(x,q)

    result = jtheta0( 1, x, q);
    
end

