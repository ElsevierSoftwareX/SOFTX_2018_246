function result = ijds( x, k)
%IJDS Return the inverse of Jacobi elliptic function DS
%     


    result = mijds( x, k^2);
    
end
