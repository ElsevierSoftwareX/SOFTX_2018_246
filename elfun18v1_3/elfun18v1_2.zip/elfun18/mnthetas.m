function result = mnthetas( u, m)
%MNTHN Neville theta function S

result = nthetas( u, melnome(m));

end