function result = ijnc( x, k)
%IJNC Returns the inverse of the Jacobi elliptic function NC
%

    result = mijnc( x, k^2);
    
end
