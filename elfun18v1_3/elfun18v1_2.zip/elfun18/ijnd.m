function result = ijnd( x, k)
%IJND Return the inverse of Jacobi elliptic function ND
%

    result = mijnd( x, k^2);
    
end
