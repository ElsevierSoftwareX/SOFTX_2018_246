function  result = ijns( x, k)
%IJNS Return the inverse of Jacobi elliptic function NS
%

    result = mijns( x, k^2);
    
end
