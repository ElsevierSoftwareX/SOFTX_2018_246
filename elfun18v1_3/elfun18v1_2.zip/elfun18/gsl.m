function result = gsl(x)
%GSL  Gauss lemniscate sin.
%
%   Functions called:
%       gslcl

    [result,~] = gslcl( x);

end

