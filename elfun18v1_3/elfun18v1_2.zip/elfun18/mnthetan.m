function result = mnthetan( u, m)
%MNTHN Neville theta function N

result = nthetan( u, melnome(m));

end